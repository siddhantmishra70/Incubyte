package com.incubyte.selenium.stepdefinition;
/** 
 * @author Ethesh Gaur
 */
public enum PageScenarioKeys implements ScenarioKeys{
	
   
}
