package com.incubyte.selenium.stepdefinition;

public interface ScenarioKeys {

}

